import fs from 'node:fs/promises';
import path from 'node:path';
import * as render from '../src/render.mjs';
import {localize} from '../src/localize.mjs';
import {draft2} from '../src/draft2.mjs';
import {addDraftSelector} from '../src/drafts.mjs';
import {load} from 'cheerio';
import {finishMetadata} from '../src/seo.mjs';
await fs.rm('dist',{recursive:true,force:true});
await fs.cp('public','dist',{recursive:true});
await fs.mkdir('dist/assets/fonts',{recursive:true});
await fs.copyFile('src/main.js','dist/assets/main.js');
await fs.copyFile('src/styles-select.js','dist/assets/styles-select.js');
for(const [family,variants] of [['cormorant-garamond',['400-normal','400-italic']],['dm-sans',['400-normal','500-normal']]])for(const variant of variants){const file=`${family}-latin-${variant}.woff2`;await fs.copyFile(`node_modules/@fontsource/${family}/files/${file}`,`dist/assets/fonts/${file}`);}
const pages=[['',render.home],['about',render.about],['11-sessions',render.sessions],['services',render.services],['yoga-nidra',render.yoga],['kambo',render.kambo],['my-art',render.art],['contact',render.contact],['impressum',render.impressum],...[...render.site.retreats,...render.site.courses].map(r=>[r.slug,()=>render.detail(r)])];
const newPages=[...pages,['music',render.art],['photography',render.art]];
const v1Routes=new Set(pages.map(([r])=>r?`/${r}/`:'/'));
const v2Routes=new Set(newPages.map(([r])=>r?`/${r}/`:'/'));
const quotes=Object.fromEntries(['de','en'].map(locale=>[locale,load(localize(render.home(),{locale}))('.testimonials').toString()]));
for(const [route,fn] of pages){
 const html=fn();const pageRoute=route?`/${route}/`:'/';
 for(const locale of ['de','en']){
  const dir=path.join('dist',locale==='en'?'en':'',route);
  await fs.mkdir(dir,{recursive:true});
  await fs.writeFile(path.join(dir,'index.html'),addDraftSelector(localize(html,{locale,route:pageRoute}),{locale,route:pageRoute,draft:1,v1Routes,v2Routes}));
 }
}
for(const [route,fn] of newPages){
 const html=fn();const pageRoute=route?`/${route}/`:'/';
 for(const locale of ['de','en']){
  const dir=path.join('dist',locale==='en'?'en':'','draft-2',route);
  await fs.mkdir(dir,{recursive:true});
  const page=draft2(localize(html,{locale,route:pageRoute}),{locale,route:pageRoute,testimonials:quotes[locale]});
  await fs.writeFile(path.join(dir,'index.html'),addDraftSelector(page,{locale,route:pageRoute,draft:2,v1Routes,v2Routes}));
 }
}
for(const locale of ['de','en'])for(const draft of [1,2]){
 let page=localize(render.notFound(),{locale,route:'/404.html'});
 if(draft===2)page=draft2(page,{locale,route:'/404.html',testimonials:quotes[locale]});
 await fs.writeFile(path.join('dist',locale==='en'?'en':'',draft===2?'draft-2':'','404.html'),addDraftSelector(page,{locale,route:'/404.html',draft,v1Routes,v2Routes}));
}
await import('./brand-assets.mjs');
await finishMetadata();
console.log(`Built ${(pages.length+newPages.length)*2} pages in two bilingual drafts plus four 404 pages. Local preview: noindex.`);
