import fs from 'node:fs/promises';
import path from 'node:path';
import {load} from 'cheerio';
const root=path.resolve('dist');const files=await fs.readdir(root,{recursive:true});const pages=files.filter(f=>f.endsWith('.html'));let failures=[];let links=0;
const images=JSON.parse(await fs.readFile('content/images.json','utf8'));const allowedImages=new Set(images.flatMap(i=>i.variants.map(v=>'/'+v.file)));
const draftContent=JSON.parse(await fs.readFile('content/draft2.json','utf8'));
for(const file of pages){
 const $=load(await fs.readFile(path.join(root,file),'utf8'));const label=m=>failures.push(`${file}: ${m}`);
 if($('h1').length!==1)label('Expected one h1');
 const englishPage=file.startsWith('en/');
 if($('html').attr('lang')!==(englishPage?'en':'de'))label('Incorrect document language');
 if($('.language-switch a').length!==2)label('Expected DE/EN switch');
 if(!file.endsWith('404.html')&&$('link[rel=alternate][hreflang]').length!==3)label('Missing language alternatives');
 const secondDraft=file.startsWith('draft-2/')||file.startsWith('en/draft-2/');
 const prefix=englishPage?'/en/draft-2/':'/draft-2/';
 if($('.draft-selector a').length!==2)label('Missing draft switch');
 if($('.draft-selector a[aria-current]').length!==1)label('Draft switch must identify the current version');
 if(secondDraft){
  $('a[href^="/"]').not('.language-switch a,.draft-selector a').each((_,e)=>{if(!$(e).attr('href').startsWith(prefix))label(`Navigation leaves Draft 2: ${$(e).attr('href')}`);});
  $('.language-switch a,link[rel=alternate]').each((_,e)=>{if(!$(e).attr('href').includes('/draft-2/'))label('Language switch leaves Draft 2');});
  if($('.revolution-banner').length>1)label('Duplicate revolution banner');
  $('.revolution-banner').each((_,e)=>{
   const b=$(e);
   if(b.attr('lang')!=='en'||b.find('.revolution-opening').text()!==draftContent.banner.opening||b.find('h2').text()!==draftContent.banner.statement||!b.find('.revolution-action').text().includes(draftContent.banner.action))label('Banner copy or language changed');
  });
  // A course testimonial must not be presented as part of the retreat testimonial pool.
  const retreatPage=['wise-in-her-ways-1','song-of-the-soul','inner-child','silent-retreat','kraft','schamanisches-retreat','services'].some(slug=>file.endsWith(`/draft-2/${slug}/index.html`)||file===`draft-2/${slug}/index.html`);
  if(retreatPage&&$('.quote strong').toArray().some(el=>['Mareike','Jonas'].includes($(el).text())))label('Non-retreat testimonial in retreat pool');
  if($('iframe[src*="soundcloud"]').length)label('SoundCloud loads before visitor action');
 }
 if(englishPage)$('a[href^="/"]').not('.language-switch a').each((_,e)=>{if(!$(e).attr('href').startsWith('/en/'))label(`English navigation leaves locale: ${$(e).attr('href')}`);});
 const footerLinks=$('.social-links a').toArray().map(e=>$(e).attr('href'));
 if(!footerLinks.some(h=>h.includes('instagram.com/aestheticmatters'))||!footerLinks.some(h=>h.includes('soundcloud.com/elena-judith'))||!footerLinks.some(h=>h.includes('youtube.com/channel/UCFYaXrnHty3oEImfCGH6WUw')))label('Missing original social link');

 const ids=new Set();$('[id]').each((_,e)=>{const id=$(e).attr('id');if(ids.has(id))label(`Duplicate id ${id}`);ids.add(id);});
 $('img').each((_,e)=>{if($(e).attr('alt')===undefined)label('Missing alt');if(!allowedImages.has($(e).attr('src')))label(`Image missing provenance: ${$(e).attr('src')}`);});
 for(const e of $('a[href],link[href],script[src],img[src]').toArray()){
  const href=$(e).attr('href')||$(e).attr('src');if(!href||/^(https?:|mailto:|tel:)/.test(href))continue;
  const base='http://local/'+file.replace(/index.html$/,'');const u=new URL(href,base);let target=path.join(root,decodeURIComponent(u.pathname));
  if(u.pathname.endsWith('/'))target=path.join(target,'index.html');
  try{const data=await fs.readFile(target);if(u.hash&&path.extname(target)==='.html'){const dest=load(data.toString());if(!dest('[id]').toArray().some(el=>dest(el).attr('id')===decodeURIComponent(u.hash.slice(1))))label(`Missing anchor ${href}`);}}catch{label(`Missing file ${href}`);}links++;
  if(secondDraft&&u.pathname.includes('/contact/')&&(u.searchParams.has('thema')||u.searchParams.has('intent'))){
   const dest=load(await fs.readFile(target,'utf8'));
   for(const key of ['thema','intent'])if(u.searchParams.has(key)&&!dest(`select[name="${key}"] option`).toArray().some(option=>dest(option).attr('value')===u.searchParams.get(key)))label(`Unrecognized enquiry ${key}: ${href}`);
  }
 }
 for(const button of $('[aria-controls]').toArray())if(!ids.has($(button).attr('aria-controls')))label('Missing disclosure target');
}
if(failures.length){console.error(failures.join('\n'));process.exit(1);}console.log(`PASS: ${pages.length} HTML pages, ${links} local links/assets, headings, IDs, image provenance and disclosure targets.`);
